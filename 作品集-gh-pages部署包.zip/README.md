# 张润安 · 数字体验作品集

个人作品集 H5，深色「数字展厅」风格：作品 / 能力 / 求职意向 / 联系方式。

## 部署到 GitHub Pages（三步）

1. 在 GitHub 新建一个**公开仓库**（如 `portfolio`）
2. 把 `index.html` 上传到仓库根目录（网页端直接拖进去即可）
3. 仓库 Settings → Pages → Source 选 `Deploy from a branch` → 分支选 `main`、目录 `/ (root)` → Save，等 1 分钟刷新

然后访问：`https://<你的用户名>.github.io/<仓库名>/`

> 说明：页面内图片为外链永久地址，无需随包上传，单文件即可运行。
